<?php
$servername="localhost";
$username="root";
$password="";
$dbname="food";
$conn=new mysqli($servername,$username,$password,$dbname);
$st=$conn->prepare("INSERT INTO user VALUES  (?,?,?,?,?,?,?)");
$st->bind_param("sissssi",$customer_name,$reg_no,$user_name,$password,$gender,$food,$order_id);
$customer_name=$_post["name"];
$reg_no=$_post["reg"];
$user_name=$_post["user_name"];
$password=$_post["pw"];
$gender=$_post["gender"];
$food=$_post["fd"];
$order_id=$_post["id"];
$st->execute();
echo "SUCCESS!";
$conn->close();
$st->close();
?>